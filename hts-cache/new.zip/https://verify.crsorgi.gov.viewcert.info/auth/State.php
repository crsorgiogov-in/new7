
<!-- Data Tabled Css  -->
<link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.14/dist/sweetalert2.all.min.js"></script>
    <!-- Fav  -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.0/jquery.fancybox.min.css" rel="stylesheet" />
    <!-- Style for Dialog Box -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.0/jquery.fancybox.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.0/jquery.fancybox.min.css">
  
<!-- font awesome icon -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  
  


<link rel="icon" href="https://crsorgi.gov.in/web/images//favicon77.ico">
    <script>
        window.location.href = '../login.php';
    </script>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="hi" lang="hi"><head>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
   <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="title" content="Civil Registration System">
    <title>Civil Registration System</title>
    <link rel="shortcut icon" href="https://crsorgi.gov.in/web/images//favicon.ico">
    <link rel="stylesheet" type="text/css" media="screen" href="../../web/css/style1.css">
<link rel="stylesheet" type="text/css" media="screen" href="../../web/css/default.css">

<link rel="stylesheet" type="text/css" media="screen" href="../../web/css/jquery.ui.all.css">
<link rel="stylesheet" type="text/css" media="screen" href="../../web/css/jquery-ui-1.10.0.custom.css">
<link rel="stylesheet" type="text/css" media="screen" href="../../web/css/jquery.ui.base.css">
    <script type="text/javascript" src="../../web/js/mm_menu.js"></script>
<script type="text/javascript" src="../../web/js/jquery-1.9.0.js"></script>
<script type="text/javascript" src="../../web/js/jquery-ui-1.10.0.custom.js"></script>
<script type="text/javascript" src="../../web/js/json_parse.js"></script>
<script type="text/javascript" src="../../web/js/jquery.ui.core.js"></script>
<script type="text/javascript" src="../../web/js/jquery.ui.datepicker-new.js"></script>
<script type="text/javascript" src="../../web/js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="../../web/js/jquery.validate.js"></script>
<script type="text/javascript" src="../../web/js/unicef.js"></script>
<script type="text/javascript" src="../../web/js/jquery.blockUI.js"></script>
	<script>


        <!-- Google Analytics code START 29122015 -->
		<!--<script async src="https://www.googletagmanager.com/gtag/js?id=G-5PT57SMG05" integrity="sha256-WgOvZ8UHNhkJlfDCu+OIO7W4+W8qznch7gOeECyHySs=" crossorigin="anonymous"></script>-->
		<script async="" src="https://www.googletagmanager.com/gtag/js?id=G-5PT57SMG05"></script>
                <script>
                 /* (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

                  ga('create', 'UA-61961116-1', 'auto');
                  ga('send', 'pageview');*/
				  
					window.dataLayer = window.dataLayer || [];
					function gtag(){dataLayer.push(arguments);}
					gtag('js', new Date());

					gtag('config', 'G-5PT57SMG05');

                </script>
        <!-- Google Analytics code END -->

   <!--xml:lang="en" lang="en"-->
            <meta http-equiv="Content-Language" content="hi">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    
    <script type="text/javascript">
      function preventBack(){
        window.history.forward();
      }

      setTimeout("preventBack()", 0);
      window.onunload=function(){null};
//    window.history.forward(-1);
    </script>

  <style type="text/css">* {<br>		-webkit-user-select: text !important;<br>		-moz-user-select: text !important;<br>		-ms-user-select: text !important;<br>		 user-select: text !important;<br>	}</style><style type="text/css">* {<br>        -webkit-user-select: text !important;<br>        -moz-user-select: text !important;<br>        -ms-user-select: text !important;<br>         user-select: text !important;<br>    }</style></head>
  <body style="zoom: 1;">
    
			
    </div>
</div><link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"><link rel="stylesheet" href="/resources/demos/style.css"><div class="fixed_modal_alert_pending" style="display:none;">
<div id="dialog-message-pending" title="Pending Request Reminder" style="color:red">
  <p>
    <span class="ui-icon ui-icon-circle-check" style="float:left; margin:0 7px 50px 0;"></span>
    <b>Total Pending Inactive User are -  . <br>Please activate the user.</b>
  </p>
  
</div>
</div><table width="100%" border="0" cellspacing="0" cellpadding="0">
	  

      
<tbody><tr style="padding: 0px !important; margin: 0px !important; line-height: 0px !important; float: left !important; height: 0px !important;">
	<td>
	<style>
	
	 .s-menu{
		visibility: hidden;
		position: absolute;
		right: -113px;
		margin-top: -25px;
		padding-left: 0px;
	}
	
	</style>
	
	
	
		<script type="text/javascript">
		<!--
		var timeout = 500;
		var closetimer = 0;
		var ddmenuitem = 0;

		// open hidden layer
		function mopen(id) {
			// cancel close timer
			mcancelclosetime();
			// close old layer
			if (ddmenuitem)
			ddmenuitem.style.visibility = 'hidden';
			// get new layer and show it
			ddmenuitem = document.getElementById(id);
			ddmenuitem.style.visibility = 'visible';
		}
		// close showed layer
		function mclose() {
			if (ddmenuitem)
			ddmenuitem.style.visibility = 'hidden';
		}

		// go close timer
		function mclosetime() {
			closetimer = window.setTimeout(mclose, timeout);
		}

		// cancel close timer
		function mcancelclosetime() {
			if (closetimer) {
				window.clearTimeout(closetimer);
				closetimer = null;
			}
		}
		// close layer when click-out
		document.onclick = mclose;
		// -->
		</script>
		
		<script type="text/javascript">
		<!--
		var timeout1 = 500;
		var closetimer1 = 0;
		var ddmenuitem1 = 0;

		// open hidden layer
		function mopen1(id) {
			// cancel close timer
			mcancelclosetime1();
			// close old layer
			if (ddmenuitem1)
			ddmenuitem1.style.visibility = 'hidden';
			// get new layer and show it
			ddmenuitem1 = document.getElementById(id);
			ddmenuitem1.style.visibility = 'visible';
		}
		// close showed layer
		function mclose1() {
			if (ddmenuitem1)
			ddmenuitem1.style.visibility = 'hidden';
		}

		// go close timer
		function mclosetime1() {
			closetimer1 = window.setTimeout(mclose1, timeout1);
		}

		// cancel close timer
		function mcancelclosetime1() {
			if (closetimer1) {
				window.clearTimeout(closetimer1);
				closetimer1 = null;
			}
		}
		// close layer when click-out
		document.onclick = mclose1;
		// -->
		</script>
		
	</td>
</tr>
<tr>
																																																										</tr>
																																																																												<script type="text/javascript">
																																																																												$(document).ready(function () {

																																																																													$("#mor>a").click(function (e) {
																date_default_timezone_set("Asia/Kolkata");																															var currtime = "1663086217";
																																																																														var starttime = "1663047000";
																																																																														var endtime = "1663057800";
																																																																														var userState = "9";
																																																																														if ((currtime >= starttime) && (currtime <= endtime)) {
																																																																															alert("Reports can not be accessed between 11 AM To 2 PM ");
																																																																															return false;
																																																																														}
																																																																													});
																																																																													var offlineVsOnlineFlag = "";
																																																																													//    console.log(offlineVsOnlineFlag)
																																																																													if (offlineVsOnlineFlag == 0) {
																																																																														$(".online").css({
																																																																															'display': 'none'
																																																																														});
																																																																													}
																																																																													else if (offlineVsOnlineFlag == 1) {
																																																																														$(".offlineOption").css({
																																																																															'display': 'none'
																																																																														});
																																																																													}
																																																																												});

                                                                                                                                                                                                                                                                                                                function Export_to_Excel_box_birth() {


                                                                                                                                                                                                                                                                                                                    var frmdt = $('#datepicker').val();
                                                                                                                                                                                                                                                                                                                    var todt = $('#datepicker1').val();

                                                                                                                                                                                                                                                                                                                    if(!frmdt || !todt){

                                                                                                                                                                                                                                                                                                                        alert('Please Select Date  !!');

                                                                                                                                                                                                                                                                                                                    }

                                                                                                                                                                                                                                                                                                                    else{

                                                                                                                                                                                                                                                                                                                        $("#pdf_excel").css('display','none');
                                                                                                                                                                                                                                                                                                                        $("#popupbox").css('display','none');
                                                                                                                                                                                                                                                                                                                        $("#fadebox").css('display','none');
                                                                                                                                                                                                                                                                                                                        $('#datepicker').val('');
                                                                                                                                                                                                                                                                                                                        $('#datepicker1').val('');

                                                                                                 $(this).css("display","none");                                                                                                                                                                                                                       window.location = "/web/index.php/birth/BirthExportReportCR/frmdt/"+frmdt+"/todt/"+todt;
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                }                                                                                                                                                                                                                                      function Export_to_Excel_box_death()
                                                                                                                                                                                                                                                                                                                {

                                                                                                                                                                                                                                                                                                                    var frmdt = $('#datepicker2').val();
                                                                                                                                                                                                                                                                                                                    var todt = $('#datepicker3').val();

                                                                                                                                                                                                                                                                                                                    if(!frmdt || !todt){

                                                                                                                                                                                                                                                                                                                        alert('Please Select Date  !!');

                                                                                                                                                                                                                                                                                                                    }

                                                                                                                                                                                                                                                                                                                    else{

                                                                                                                                                                                                                                                                                                                        $("#pdf_excel").css('display','none');
                                                                                                                                                                                                                                                                                                                        $("#popupbox").css('display','none');
                                                                                                                                                                                                                                                                                                                        $("#fadebox").css('display','none');
                                                                                                                                                                                                                                                                                                                        $('#datepicker2').val('');
                                                                                                                                                                                                                                                                                                                        $('#datepicker3').val('');

                                                                                                                                                                                                                                                                                                                        $(this).css("display","none");                                                                                                                                            window.location = "/web/index.php/death/DeathExportReportCR/frmdt/"+frmdt+"/todt/"+todt;
                                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                                }                                                                                                                                                                                                                                                                                                              </script>




<!-- birth,death,stillbirth reports calender--> 

																																																																												
																																																																												
<!--birth start-->	
<style>
    .fixed_modal{position: fixed; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 99; display:none;}
	.fixed_modal1{position: fixed; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 99; display:none;}
</style>




		<!-- birth end-->

      <tr>
<td valign="middle" class="welcome-strip-bg" style="border: none !important;">
 <table cellspacing="0" cellpadding="0" border="0" align="center" width="96%">
 <tbody><tr>
   <td align="left" width="46%" class="welcome-clock">
   	<div class="datetime">
<span id="live_date">Tuesday, September 13, 2022</span>
<span id="live_clock">22:00:32 IST </span>
</div>

<script type="text/javascript">
var lcl = new Date();
function synctime(x){
 lcl = new Date(x);
}

    function shdate(){
      if (!document.layers && !document.all && !document.getElementById)
        return;
        mnth = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        day_name=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
        var dayname = day_name[lcl.getDay()];
        var dd=lcl.getDate();
        var mm=lcl.getMonth();
        var yy=lcl.getFullYear();
        //dtdp = dd+" "+mnth[mm]+" "+yy+", ";
        dtdp = dayname +", "+mnth[mm]+" "+dd+", "+yy+", ";
       dtdp = dayname +", "+mnth[mm]+" "+dd+", "+yy+", ";

        if (document.layers)
        {
            document.layers.live_date.document.write(dtdp);
            document.layers.live_date.document.close();
        }
        else if (document.all)
        {
            live_date.innerHTML=dtdp;
        }
        else if (document.getElementById)
        {
            document.getElementById("live_date").innerHTML=dtdp;
        }
    }

    function show5()
    {
        if (!document.layers && !document.all && !document.getElementById)
        return;

        lcl.setSeconds(lcl.getSeconds()+1);

        var hours=lcl.getHours();
        var minutes=lcl.getMinutes();
        var seconds=lcl.getSeconds();
        var dn="PM";

        if (minutes<=9)
        minutes="0"+minutes;
        if (seconds<=9)
        seconds="0"+seconds;

        myclock=hours+":"+minutes+":"+seconds+" IST ";

    if (document.layers)
    {
        document.layers.live_clock.document.write(myclock);
        document.layers.live_clock.document.close();
    }
    else if (document.all)
    {
        live_clock.innerHTML=myclock;
    }
    else if (document.getElementById)
    {
        document.getElementById("live_clock").innerHTML=myclock;
    }

        setTimeout("show5()", 1000);
    }

shdate();
show5();
</script>   </td>
    </script>   </td>
    <td class="welcome-clock" colspan="2" align="right" style="
    padding-top: 10px;
">
  	 <label class="welcome-welcome"> WELCOME&nbsp;:&nbsp;</label>
  	 <label class="welcome-user-name">  &nbsp; -  (Sub Registrar) 
   		 
   		<!-- <span style="font-weight:normal;">Registration Unit No :</span>  -->
   	 </label>
         <label class="welcome"> 
         
         
         
         
    
   		<!-- <span style="font-weight:normal;">Registration Unit No :</span>  -->
   	 </label>
   </td><!DOCTYPE html>
<!-- saved from url=(0021)https://uidai.gov.in/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<base href="/">--><base href=".">

	<!-- CSS only -->
	<link href="./State_files/bootstrap5_1_3.min.css" rel="stylesheet" type="text/css">
	<link href="./State_files/fonts-local_roboto.css" rel="stylesheet" type="text/css">
	<link href="./State_files/langpage_style.css" rel="stylesheet" type="text/css">
    <title>State Selection - Civil Registration System</title>
	<link rel="shortcut icon" href="https://crsorgi.gov.in/web/images//favicon.ico" type="image/vnd.microsoft.icon">
	<style>
	
		.wb:after{	content: "Uttar Pradesh";}.wb:hover:after{	content: "उत्तर प्रदेश";}.bh:after{	content: "Bihar";}.bh:hover:after{	content: "बिहार";} .jh:after{	content: "Jharkhand";}.jh:hover:after{	content: "झारखण्ड";} .jk:after{	content: "Jammu and Kashmir";}.jk:hover:after{	content: "जम्मू कश्मीर";}   .mp:after{	content: "Madhya Pradesh";}.mp:hover:after{	content: "मध्य प्रदेश";}    .uk:after{	content: "Uttarakhand";}.uk:hover:after{	content: "उत्तराखंड";}.tg:after{	content: "Telangana";}.tg:hover:after{	content: "తెలంగాణ";}.as:after{	content: "Assam";}.as:hover:after{	content: "অসম";}	</style>
</head>
<body>
	
	
	<div class="back col-sm-12 container-fluid">
	<center>
		<div class="btn-div col-sm-10" role="group" aria-label="Basic example">
			
			<div class="m-t"><p class="text-responsive " style="
    padding-top: 160px;
">Select your State to Enter the Website</p><p class="text-responsive ">वेबसाइट में प्रवेश करने के लिए अपने राज्य का चयन करें</p></div>
			<div class="container-fluid">
				<button type="button" onclick="document.location.replace(&#39;index_up.php&#39;);" class="btn btn1 wb">Uttar Pradesh</button><button type="button" onclick="document.location.replace(&#39;index_bh.php&#39;);" class="btn btn1 bh">Bihar</button><button type="button" onclick="document.location.replace(&#39;index_jh.php&#39;);" class="btn btn1 jh">Jharkhand</button>	<button type="button" onclick="document.location.replace(&#39;index_jk.php&#39;);" class="btn btn1 jk">Jharkhand</button><button type="button" onclick="document.location.replace(&#39;index_mp.php&#39;);" class="btn btn1 mp">Madhya Pradesh</button><button type="button" onclick="document.location.replace(&#39;index_uk.php&#39;);" class="btn btn1 uk">Uttarakhand</button><button type="button" onclick="document.location.replace(&#39;index_tg.php&#39;);" class="btn btn1 tg">Uttarakhand</button><button type="button" onclick="document.location.replace(&#39;index_as.php&#39;);" class="btn btn1 as">Assam</button>		</div>
		</div>
	</center>
	</div>

</body></html>